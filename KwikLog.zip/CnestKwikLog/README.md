# CnestKwikLog v2.0.0

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![PowerShell](https://img.shields.io/badge/PowerShell-5.1+-blue.svg)](https://docs.microsoft.com/en-us/powershell/)
[![Windows](https://img.shields.io/badge/Windows-7+-green.svg)](https://www.microsoft.com/windows/)

**Production-Ready System Information Collector for Windows Incident Response**

A reliable, zero-install, read-only system information collector designed for Windows incident response and system analysis. CnestKwikLog provides comprehensive system information collection with privacy controls, error handling, and neat artifacts.

##  Features

- **Zero-Install**: No dependencies, runs on any Windows 7+ system with PowerShell
- **Read-Only**: Safe, non-destructive operations that don't modify the system
- **Privacy Controls**: Built-in privacy mode to redact sensitive information
- **Reliable**: Comprehensive error handling and recovery mechanisms
- **Neat Artifacts**: Well-organized, timestamped output files

##  Requirements

- Windows 7 or later
- PowerShell 2.0+ (included with Windows 7+)
- Administrator privileges (recommended for full data collection)

##  Quick Start

### Basic Usage
```batch
# Double-click CnestKwikLog.bat or run from command line
CnestKwikLog.bat
```

### Privacy Mode
```batch
# Enable privacy mode to redact sensitive data
CnestKwikLog.bat -PrivacyMode
```

### Custom Output Directory
```batch
# Specify custom log directory
CnestKwikLog.bat -LogPath "C:\IncidentResponse\Logs"
```

### Verbose Logging
```batch
# Enable verbose logging for debugging
CnestKwikLog.bat -Verbose
```

##  File Structure

```
CnestKwikLog/
├── CnestKwikLog.bat              # Main launcher script
├── src/
│   ├── core/
│   │   └── CnestKwikLog.ps1      # Core PowerShell collector
│   ├── modules/                  # Optional modules
│   └── utils/                    # Utility functions
├── docs/                         # Documentation
├── tests/                        # Test scripts
├── examples/                     # Usage examples
└── Logs/                         # Output directory
    └── LogYYYYMMDD_HHMMSS/       # Timestamped log directories
```

##  Collected Information

### System Information
- Operating system details
- Hardware specifications
- System configuration

### Hardware Details
- Processor information
- Memory configuration
- Storage devices
- Graphics adapters

### Network Configuration
- Network adapters
- IP configuration
- Network routes
- Active connections

### Process Information
- Running processes (top 50)
- Windows services
- System processes

### Software Inventory
- Installed programs
- Registry entries
- System components

### Environment Data
- Environment variables
- System PATH
- User profiles

### Event Logs
- Recent system events
- Application events
- Security events (if accessible)

### Disk Information
- Disk usage statistics
- File system information
- Volume details

##  Privacy Features

When privacy mode is enabled (`-PrivacyMode`), the following data is automatically redacted:

- User names and domains
- Computer names
- MAC addresses
- IP addresses
- Product keys
- Serial numbers
- Installation dates
- Network identifiers

##  Output Files

All data is saved as UTF-8 encoded text files in timestamped directories:

- `00_CollectionSummary.txt` - Overview and summary
- `01_SystemInfo.txt` - Basic system information
- `02_OSDetails.txt` - Operating system details
- `03_Processor.txt` - CPU information
- `04_Memory.txt` - RAM details
- `05_Storage.txt` - Storage devices
- `06_Graphics.txt` - Graphics information
- `07_NetworkAdapters.txt` - Network adapters
- `08_IPConfig.txt` - IP configuration
- `09_NetworkRoutes.txt` - Network routes
- `10_RunningProcesses.txt` - Active processes
- `11_RunningServices.txt` - Windows services
- `12_InstalledSoftware.txt` - Installed programs
- `13_RegistryPrograms.txt` - Registry programs
- `14_Environment.txt` - Environment variables
- `15_SystemPath.txt` - System PATH
- `16_RecentEvents.txt` - Recent event logs
- `17_DiskUsage.txt` - Disk usage
- `collection.log` - Collection log

##  Advanced Usage

### PowerShell Direct Execution
```powershell
# Run PowerShell script directly
.\src\core\CnestKwikLog.ps1 -LogPath "C:\Logs" -PrivacyMode -Verbose
```

### Configuration File
```json
{
    "privacyMode": true,
    "verbose": false,
    "timeoutSeconds": 30,
    "maxProcesses": 50,
    "maxEvents": 100
}
```

### Custom Modules
```powershell
# Load custom collection modules
Import-Module .\src\modules\CustomCollector.psm1
```

##  Troubleshooting

### PowerShell Execution Policy
If you encounter execution policy errors:

```powershell
# Run as Administrator
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# Or bypass for single execution
powershell -ExecutionPolicy Bypass -File CnestKwikLog.ps1
```

### Permission Issues
- Run as Administrator for full data collection
- Some information may be limited without elevated privileges
- Check Windows Event Logs for detailed error information

### Disk Space
- Ensure sufficient disk space for log files
- Typical collection size: 1-5 MB
- Large software inventories may increase size

##  Documentation

- [User Guide](docs/USER_GUIDE.md) - Detailed usage instructions
- [Developer Guide](docs/DEVELOPER_GUIDE.md) - Development and customization
- [API Reference](docs/API_REFERENCE.md) - Function and parameter reference
- [Examples](examples/) - Usage examples and scenarios

##  Testing

```batch
# Run test suite
.\tests\run_tests.bat

# Run specific tests
.\tests\test_privacy.bat
.\tests\test_collection.bat
```

##  Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

##  License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

##  Acknowledgments

- **CyberNest** - For the original concept and requirements
- **Auxk0rd** - Primary developer and maintainer
- **PowerShell Community** - For excellent documentation and examples
- **Windows Incident Response Community** - For feedback and testing


---

**KwikLog v2.0.0** - System Information Collector  

