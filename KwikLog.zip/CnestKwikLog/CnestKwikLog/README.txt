KwikLog - Pure CLI MVP System Information Collector
========================================================

A lightweight, self-contained system information collector for Windows 7+.
No GUI, no popups - just pure command-line interface.

USAGE:
------
1. Double-click CnestKwikLog.bat to run
2. The tool will automatically:
   - Create a new log directory (Logs\Log1, Logs\Log2, etc.)
   - Collect comprehensive system information
   - Save all data as text files
   - Open the log directory when complete

REQUIREMENTS:
-------------
- Windows 7 or later
- PowerShell (included with Windows 7+)
- Administrator privileges (recommended for full data collection)

COLLECTED INFORMATION:
---------------------
- System Information (OS, hardware specs)
- Processor details
- Memory information
- Storage devices
- Graphics adapters
- Network configuration
- Running processes (top 50)
- Running services
- Installed software
- Environment variables
- Recent event logs
- Disk usage statistics

OUTPUT:
-------
All data is saved as UTF-8 encoded text files in the Logs\LogN directory:
- 00_CollectionSummary.txt - Overview of collected data
- 01_SystemInfo.txt - Basic system information
- 02_OSDetails.txt - Operating system details
- 03_Processor.txt - CPU information
- 04_Memory.txt - RAM details
- 05_Storage.txt - Hard drives and storage
- 06_Graphics.txt - Video card information
- 07_NetworkAdapters.txt - Network interface cards
- 08_IPConfig.txt - IP configuration
- 09_RunningProcesses.txt - Active processes
- 10_RunningServices.txt - Windows services
- 11_InstalledSoftware.txt - Installed programs
- 12_Environment.txt - Environment variables
- 13_SystemPath.txt - System PATH variable
- 14_RecentEvents.txt - Recent system events
- 15_DiskUsage.txt - Disk space information

TROUBLESHOOTING:
----------------
If you get PowerShell execution policy errors:
1. Run Command Prompt as Administrator
2. Execute: powershell -ExecutionPolicy Bypass -File CnestKwikLog.ps1 -LogPath "Logs\Log1"
3. Or set execution policy: Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

FEATURES:
---------
- Fully self-contained (no external dependencies)
- Windows 7+ compatible
- Automatic log directory management
- Error handling and logging
- Progress indicators
- UTF-8 encoding for international characters
- Safe command execution with error recovery

Version: 1.0 MVP
License: MIT
Written by Auxk0rd for CyberNest 2025
