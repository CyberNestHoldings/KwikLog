param(
    [Parameter(Mandatory=$true)]
    [string]$LogPath
)

function Write-LogEntry {
    param([string]$Message)
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] $Message" -ForegroundColor Green
}

function Invoke-SafeCommand {
    param(
        [string]$Command,
        [string]$Description,
        [string]$OutputFile
    )
    
    Write-LogEntry "Collecting: $Description"
    
    try {
        $result = Invoke-Expression $Command 2>&1
        if ($result) {
            $result | Out-File -FilePath $OutputFile -Encoding UTF8
            Write-LogEntry "Success: $Description - Saved to $OutputFile"
        } else {
            "No data available for $Description" | Out-File -FilePath $OutputFile -Encoding UTF8
            Write-LogEntry "Warning: $Description - No data available"
        }
    }
    catch {
        "Error collecting $Description`: $($_.Exception.Message)" | Out-File -FilePath $OutputFile -Encoding UTF8
        Write-LogEntry "Error: $Description - $($_.Exception.Message)"
    }
}

if (!(Test-Path $LogPath)) {
    New-Item -ItemType Directory -Path $LogPath -Force | Out-Null
}

Write-LogEntry "Starting CnestKwikLog collection..."
Write-LogEntry "Log directory: $LogPath"

Write-LogEntry "=== SYSTEM INFORMATION ==="
Invoke-SafeCommand -Command "Get-ComputerInfo | Select-Object WindowsProductName, WindowsVersion, WindowsBuildLabEx, TotalPhysicalMemory, CsProcessors, CsSystemType" -Description "System Information" -OutputFile "$LogPath\01_SystemInfo.txt"

Invoke-SafeCommand -Command "Get-WmiObject -Class Win32_OperatingSystem | Select-Object Caption, Version, BuildNumber, InstallDate, LastBootUpTime, TotalVisibleMemorySize, FreePhysicalMemory" -Description "Operating System Details" -OutputFile "$LogPath\02_OSDetails.txt"

Write-LogEntry "=== HARDWARE INFORMATION ==="
Invoke-SafeCommand -Command "Get-WmiObject -Class Win32_Processor | Select-Object Name, Manufacturer, MaxClockSpeed, NumberOfCores, NumberOfLogicalProcessors" -Description "Processor Information" -OutputFile "$LogPath\03_Processor.txt"

Invoke-SafeCommand -Command "Get-WmiObject -Class Win32_PhysicalMemory | Select-Object Capacity, Speed, Manufacturer, PartNumber" -Description "Memory Information" -OutputFile "$LogPath\04_Memory.txt"

Invoke-SafeCommand -Command "Get-WmiObject -Class Win32_DiskDrive | Select-Object Model, Size, InterfaceType, MediaType" -Description "Storage Information" -OutputFile "$LogPath\05_Storage.txt"

Invoke-SafeCommand -Command "Get-WmiObject -Class Win32_VideoController | Select-Object Name, AdapterRAM, DriverVersion" -Description "Graphics Information" -OutputFile "$LogPath\06_Graphics.txt"

Write-LogEntry "=== NETWORK INFORMATION ==="
Invoke-SafeCommand -Command "Get-WmiObject -Class Win32_NetworkAdapter | Where-Object {`$_.NetConnectionStatus -eq 2} | Select-Object Name, AdapterType, Speed, MACAddress" -Description "Network Adapters" -OutputFile "$LogPath\07_NetworkAdapters.txt"

Invoke-SafeCommand -Command "ipconfig /all" -Description "IP Configuration" -OutputFile "$LogPath\08_IPConfig.txt"

Write-LogEntry "=== RUNNING PROCESSES ==="
Invoke-SafeCommand -Command "Get-Process | Select-Object ProcessName, Id, CPU, WorkingSet, StartTime | Sort-Object CPU -Descending | Select-Object -First 50" -Description "Top 50 Running Processes" -OutputFile "$LogPath\09_RunningProcesses.txt"

Write-LogEntry "=== SERVICES ==="
Invoke-SafeCommand -Command "Get-Service | Where-Object {`$_.Status -eq 'Running'} | Select-Object Name, DisplayName, Status, StartType | Sort-Object Name" -Description "Running Services" -OutputFile "$LogPath\10_RunningServices.txt"

Write-LogEntry "=== INSTALLED SOFTWARE ==="
Invoke-SafeCommand -Command "Get-WmiObject -Class Win32_Product | Select-Object Name, Version, Vendor, InstallDate | Sort-Object Name" -Description "Installed Software" -OutputFile "$LogPath\11_InstalledSoftware.txt"

Write-LogEntry "=== ENVIRONMENT ==="
Invoke-SafeCommand -Command "Get-ChildItem Env: | Sort-Object Name" -Description "Environment Variables" -OutputFile "$LogPath\12_Environment.txt"

Invoke-SafeCommand -Command "Get-ChildItem Env:PATH" -Description "System PATH" -OutputFile "$LogPath\13_SystemPath.txt"

Write-LogEntry "=== EVENT LOGS ==="
try {
    $yesterday = (Get-Date).AddDays(-1)
    Get-WinEvent -FilterHashtable @{LogName='System','Application'; Level=1,2,3; StartTime=$yesterday} -MaxEvents 100 -ErrorAction SilentlyContinue | 
    Select-Object TimeCreated, Id, LevelDisplayName, LogName, ProviderName, Message | 
    Sort-Object TimeCreated -Descending |
    Out-File -FilePath "$LogPath\14_RecentEvents.txt" -Encoding UTF8
    Write-LogEntry "Success: Recent Event Logs - Saved to 14_RecentEvents.txt"
}
catch {
    "Error collecting event logs: $($_.Exception.Message)" | Out-File -FilePath "$LogPath\14_RecentEvents.txt" -Encoding UTF8
    Write-LogEntry "Error: Recent Event Logs - $($_.Exception.Message)"
}

Write-LogEntry "=== DISK USAGE ==="
Invoke-SafeCommand -Command "Get-WmiObject -Class Win32_LogicalDisk | Select-Object DeviceID, Size, FreeSpace, FileSystem" -Description "Disk Usage" -OutputFile "$LogPath\15_DiskUsage.txt"

Write-LogEntry "=== CREATING SUMMARY REPORT ==="
$summary = "CnestKwikLog Collection Summary`n"
$summary += "Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')`n"
$summary += "Log Directory: $LogPath`n`n"
$summary += "Collection completed successfully with the following files:`n"

$logFiles = Get-ChildItem -Path $LogPath -Filter "*.txt" | Sort-Object Name
foreach ($file in $logFiles) {
    $summary += "- $($file.Name) ($([math]::Round($file.Length/1KB, 2)) KB)`n"
}

$summary | Out-File -FilePath "$LogPath\00_CollectionSummary.txt" -Encoding UTF8

Write-LogEntry "Collection completed successfully!"
Write-LogEntry "Total files created: $($logFiles.Count + 1)"
Write-LogEntry "Log directory: $LogPath"