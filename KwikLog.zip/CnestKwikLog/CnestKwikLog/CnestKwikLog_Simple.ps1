param(
    [Parameter(Mandatory=$true)]
    [string]$LogPath
)

function Write-LogEntry {
    param([string]$Message)
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] $Message" -ForegroundColor Green
}

function Invoke-SafeCommand {
    param(
        [string]$Command,
        [string]$Description,
        [string]$OutputFile
    )
    
    Write-LogEntry "Collecting: $Description"
    
    try {
        $result = Invoke-Expression $Command 2>&1
        if ($result) {
            $result | Out-File -FilePath $OutputFile -Encoding UTF8
            Write-LogEntry "Success: $Description"
        } else {
            "No data available for $Description" | Out-File -FilePath $OutputFile -Encoding UTF8
            Write-LogEntry "Warning: $Description - No data available"
        }
    }
    catch {
        "Error collecting $Description`: $($_.Exception.Message)" | Out-File -FilePath $OutputFile -Encoding UTF8
        Write-LogEntry "Error: $Description - $($_.Exception.Message)"
    }
}

if (!(Test-Path $LogPath)) {
    New-Item -ItemType Directory -Path $LogPath -Force | Out-Null
}

Write-LogEntry "Starting CnestKwikLog collection..."
Write-LogEntry "Log directory: $LogPath"

Invoke-SafeCommand -Command "Get-ComputerInfo" -Description "System Information" -OutputFile "$LogPath\01_SystemInfo.txt"
Invoke-SafeCommand -Command "Get-WmiObject -Class Win32_OperatingSystem" -Description "OS Details" -OutputFile "$LogPath\02_OSDetails.txt"
Invoke-SafeCommand -Command "Get-WmiObject -Class Win32_Processor" -Description "Processor" -OutputFile "$LogPath\03_Processor.txt"
Invoke-SafeCommand -Command "Get-WmiObject -Class Win32_PhysicalMemory" -Description "Memory" -OutputFile "$LogPath\04_Memory.txt"
Invoke-SafeCommand -Command "ipconfig /all" -Description "Network Config" -OutputFile "$LogPath\05_Network.txt"

Write-LogEntry "Collection completed successfully!"
