# CnestKwikLog User Guide

## Table of Contents
1. [Installation](#installation)
2. [Basic Usage](#basic-usage)
3. [Advanced Usage](#advanced-usage)
4. [Privacy Features](#privacy-features)
5. [Output Files](#output-files)
6. [Troubleshooting](#troubleshooting)
7. [Best Practices](#best-practices)

## Installation

CnestKwikLog requires no installation. Simply download the files and run:

```batch
CnestKwikLog.bat
```

### Requirements
- Windows 7 or later
- PowerShell 2.0+ (included with Windows 7+)
- Administrator privileges (recommended)

## Basic Usage

### Quick Start
1. Double-click `CnestKwikLog.bat`
2. Wait for collection to complete
3. Review the generated log files

### Command Line Options
```batch
CnestKwikLog.bat [OPTIONS]

OPTIONS:
  -LogPath <path>        Output directory
  -PrivacyMode           Enable privacy mode
  -Verbose               Enable verbose logging
  -ConfigFile <path>     Configuration file
  -h, --help, -help      Show help
```

### Examples
```batch
# Basic collection
CnestKwikLog.bat

# Privacy mode
CnestKwikLog.bat -PrivacyMode

# Custom output directory
CnestKwikLog.bat -LogPath "C:\IncidentResponse\Logs"

# Verbose logging
CnestKwikLog.bat -Verbose

# Combined options
CnestKwikLog.bat -PrivacyMode -Verbose -LogPath "C:\Logs"
```

## Advanced Usage

### PowerShell Direct Execution
```powershell
# Run PowerShell script directly
.\src\core\CnestKwikLog.ps1 -LogPath "C:\Logs" -PrivacyMode -Verbose
```

### Configuration File
Create a `config.json` file:
```json
{
    "privacyMode": true,
    "verbose": false,
    "timeoutSeconds": 30,
    "maxProcesses": 50,
    "maxEvents": 100
}
```

### Custom Modules
```powershell
# Load custom collection modules
Import-Module .\src\modules\CustomCollector.psm1
```

## Privacy Features

### Privacy Mode
When enabled, privacy mode redacts sensitive information:

- User names and domains
- Computer names
- MAC addresses
- IP addresses
- Product keys
- Serial numbers
- Installation dates
- Network identifiers

### Enabling Privacy Mode
```batch
# Via batch launcher
CnestKwikLog.bat -PrivacyMode

# Via PowerShell
.\src\core\CnestKwikLog.ps1 -PrivacyMode
```

### Privacy Data Redaction
The following data types are automatically redacted:
- `[REDACTED]` - General sensitive data
- `[IP_REDACTED]` - IP addresses
- `[MAC_REDACTED]` - MAC addresses
- `[PRODUCT_KEY_REDACTED]` - Product keys

## Output Files

### File Structure
```
Logs/
└── LogYYYYMMDD_HHMMSS/
    ├── 00_CollectionSummary.txt
    ├── 01_SystemInfo.txt
    ├── 02_OSDetails.txt
    ├── 03_Processor.txt
    ├── 04_Memory.txt
    ├── 05_Storage.txt
    ├── 06_Graphics.txt
    ├── 07_NetworkAdapters.txt
    ├── 08_IPConfig.txt
    ├── 09_NetworkRoutes.txt
    ├── 10_RunningProcesses.txt
    ├── 11_RunningServices.txt
    ├── 12_InstalledSoftware.txt
    ├── 13_RegistryPrograms.txt
    ├── 14_Environment.txt
    ├── 15_SystemPath.txt
    ├── 16_RecentEvents.txt
    ├── 17_DiskUsage.txt
    └── collection.log
```

### File Descriptions
- **00_CollectionSummary.txt** - Overview and summary of collection
- **01_SystemInfo.txt** - Basic system information
- **02_OSDetails.txt** - Operating system details
- **03_Processor.txt** - CPU information
- **04_Memory.txt** - RAM details
- **05_Storage.txt** - Storage devices
- **06_Graphics.txt** - Graphics information
- **07_NetworkAdapters.txt** - Network adapters
- **08_IPConfig.txt** - IP configuration
- **09_NetworkRoutes.txt** - Network routes
- **10_RunningProcesses.txt** - Active processes
- **11_RunningServices.txt** - Windows services
- **12_InstalledSoftware.txt** - Installed programs
- **13_RegistryPrograms.txt** - Registry programs
- **14_Environment.txt** - Environment variables
- **15_SystemPath.txt** - System PATH
- **16_RecentEvents.txt** - Recent event logs
- **17_DiskUsage.txt** - Disk usage
- **collection.log** - Collection log

## Troubleshooting

### Common Issues

#### PowerShell Execution Policy
**Error**: Execution policy prevents script execution

**Solution**:
```powershell
# Run as Administrator
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# Or bypass for single execution
powershell -ExecutionPolicy Bypass -File CnestKwikLog.ps1
```

#### Permission Denied
**Error**: Access denied or insufficient privileges

**Solution**:
- Run as Administrator
- Check file permissions
- Ensure sufficient disk space

#### Script Not Found
**Error**: PowerShell script not found

**Solution**:
- Verify file structure
- Check file paths
- Ensure script is in correct location

#### Collection Timeout
**Error**: Command timed out

**Solution**:
- Increase timeout in configuration
- Check system performance
- Run with verbose logging for details

### Debug Mode
Enable verbose logging for detailed information:
```batch
CnestKwikLog.bat -Verbose
```

### Log Analysis
Check the `collection.log` file for detailed error information:
```
[2025-10-16 22:45:21] [ERROR] Failed to collect network information
[2025-10-16 22:45:21] [DEBUG] Command: Get-WmiObject -Class Win32_NetworkAdapter
[2025-10-16 22:45:21] [DEBUG] Error: Access denied
```

## Best Practices

### Incident Response
1. **Run as Administrator** for complete data collection
2. **Use Privacy Mode** when sharing logs
3. **Document collection time** for timeline analysis
4. **Verify log integrity** before analysis
5. **Store logs securely** with proper access controls

### System Analysis
1. **Baseline collections** for comparison
2. **Regular collections** for monitoring
3. **Privacy considerations** for sensitive environments
4. **Log retention** policies
5. **Access controls** for log files

### Performance
1. **Run during low-usage periods** for better performance
2. **Monitor disk space** for large collections
3. **Use timeout settings** for slow systems
4. **Consider network impact** for remote systems

### Security
1. **Validate log integrity** before analysis
2. **Use secure storage** for sensitive logs
3. **Implement access controls** for log files
4. **Regular security reviews** of collection process
5. **Monitor for unauthorized access** to logs

## Support

For additional support:
- Check the [GitHub Issues](https://github.com/auxk0rd/CnestKwikLog/issues)
- Review the [Developer Guide](DEVELOPER_GUIDE.md)
- Consult the [API Reference](API_REFERENCE.md)
- Join the [Discussions](https://github.com/auxk0rd/CnestKwikLog/discussions)
