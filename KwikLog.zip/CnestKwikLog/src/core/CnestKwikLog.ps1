# CnestKwikLog - Production-Ready System Information Collector
# Version: 2.0.0
# Author: Auxk0rd for CyberNest 2025
# License: MIT
# 
# A reliable, zero-install, read-only system information collector for Windows incident response.
# Features: Privacy controls, error handling, neat artifacts, and GitHub readiness.

[CmdletBinding()]
param(
    [Parameter(Mandatory=$false)]
    [string]$LogPath = ".\Logs\Log$(Get-Date -Format 'yyyyMMdd_HHmmss')",
    
    [Parameter(Mandatory=$false)]
    [switch]$PrivacyMode,
    
    [Parameter(Mandatory=$false)]
    [switch]$Verbose,
    
    [Parameter(Mandatory=$false)]
    [string]$ConfigFile = ".\config.json",
    
    [Parameter(Mandatory=$false)]
    [switch]$Help
)

#region Configuration and Constants
$SCRIPT_VERSION = "2.0.0"
$SCRIPT_NAME = "CnestKwikLog"
$COMPANY = "CyberNest"
$AUTHOR = "Auxk0rd"

# Privacy-sensitive fields to sanitize
$PRIVACY_FIELDS = @(
    "UserName", "UserDomain", "ComputerName", "MACAddress", "SerialNumber",
    "InstallDate", "LastBootUpTime", "IPAddress", "DNSHostName", "Domain",
    "Workgroup", "ProductKey", "InstallDate", "RegisteredUser", "Organization"
)

# Error codes
$ERROR_CODES = @{
    SUCCESS = 0
    INVALID_PARAMETER = 1
    PERMISSION_DENIED = 2
    FILE_SYSTEM_ERROR = 3
    POWERSHELL_ERROR = 4
    CONFIGURATION_ERROR = 5
}
#endregion

#region Logging Functions
function Write-LogEntry {
    param(
        [string]$Message,
        [string]$Level = "INFO",
        [switch]$NoTimestamp
    )
    
    $timestamp = if (-not $NoTimestamp) { Get-Date -Format "yyyy-MM-dd HH:mm:ss" } else { "" }
    $color = switch ($Level) {
        "ERROR" { "Red" }
        "WARN" { "Yellow" }
        "SUCCESS" { "Green" }
        "DEBUG" { "Cyan" }
        default { "White" }
    }
    
    $logMessage = if ($timestamp) { "[$timestamp] [$Level] $Message" } else { $Message }
    Write-Host $logMessage -ForegroundColor $color
    
    # Also log to file if available
    if ($global:LogFile) {
        Add-Content -Path $global:LogFile -Value $logMessage -Encoding UTF8
    }
}

function Write-Header {
    param([string]$Title)
    Write-LogEntry "========================================" -NoTimestamp
    Write-LogEntry " $Title" -NoTimestamp
    Write-LogEntry "========================================" -NoTimestamp
}
#endregion

#region Privacy Functions
function Remove-PrivacyData {
    param([string]$Content)
    
    if (-not $PrivacyMode) {
        return $Content
    }
    
    $sanitized = $Content
    foreach ($field in $PRIVACY_FIELDS) {
        $replacement = $field + ' [REDACTED]'
        $sanitized = $sanitized -replace "(?i)$field\s*[:=]\s*[^\r\n]+", $replacement
        $sanitized = $sanitized -replace "(?i)$field\s*:\s*[^\r\n]+", $replacement
    }
    
    # Additional privacy sanitization
    $sanitized = $sanitized -replace "\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b", "[IP_REDACTED]"
    $sanitized = $sanitized -replace "\b[A-F0-9]{2}[:-][A-F0-9]{2}[:-][A-F0-9]{2}[:-][A-F0-9]{2}[:-][A-F0-9]{2}[:-][A-F0-9]{2}\b", "[MAC_REDACTED]"
    $sanitized = $sanitized -replace "\b[A-Z0-9]{5}-[A-Z0-9]{5}-[A-Z0-9]{5}-[A-Z0-9]{5}-[A-Z0-9]{5}\b", "[PRODUCT_KEY_REDACTED]"
    
    return $sanitized
}

function Test-PrivacyMode {
    if ($PrivacyMode) {
        Write-LogEntry "Privacy mode enabled - sensitive data will be redacted" "WARN"
    }
}
#endregion

#region Safe Command Execution
function Invoke-SafeCommand {
    param(
        [string]$Command,
        [string]$Description,
        [string]$OutputFile,
        [int]$TimeoutSeconds = 30,
        [switch]$IgnoreErrors
    )
    
    Write-LogEntry "Collecting: $Description" "DEBUG"
    
    try {
        # Create a job to handle timeout
        $job = Start-Job -ScriptBlock {
            param($cmd)
            try {
                return Invoke-Expression $cmd 2>&1
            }
            catch {
                return "Error: $($_.Exception.Message)"
            }
        } -ArgumentList $Command
        
        # Wait for job with timeout
        $result = Wait-Job $job -Timeout $TimeoutSeconds
        
        if ($result) {
            $output = Receive-Job $job
            Remove-Job $job -Force
            
            if ($output -and $output -notmatch "Error:") {
                $sanitizedOutput = Remove-PrivacyData -Content ($output | Out-String)
                $sanitizedOutput | Out-File -FilePath $OutputFile -Encoding UTF8 -NoNewline
                Write-LogEntry "✓ $Description - Saved to $(Split-Path $OutputFile -Leaf)" "SUCCESS"
                return $true
            } else {
                "No data available for $Description" | Out-File -FilePath $OutputFile -Encoding UTF8
                Write-LogEntry "⚠ $Description - No data available" "WARN"
                return $false
            }
        } else {
            Remove-Job $job -Force
            "Command timed out after $TimeoutSeconds seconds" | Out-File -FilePath $OutputFile -Encoding UTF8
            Write-LogEntry "⚠ $Description - Command timed out" "WARN"
            return $false
        }
    }
    catch {
        $errorMsg = "Error collecting $Description`: $($_.Exception.Message)"
        $errorMsg | Out-File -FilePath $OutputFile -Encoding UTF8
        Write-LogEntry "✗ $Description - $($_.Exception.Message)" "ERROR"
        return $false
    }
}
#endregion

#region System Information Collection
function Get-SystemInformation {
    param([string]$LogPath)
    
    Write-Header "SYSTEM INFORMATION"
    
    $commands = @(
        @{
            Command = "Get-ComputerInfo | Select-Object WindowsProductName, WindowsVersion, WindowsBuildLabEx, TotalPhysicalMemory, CsProcessors, CsSystemType, CsDomain, CsWorkgroup"
            Description = "System Information"
            OutputFile = "$LogPath\01_SystemInfo.txt"
        },
        @{
            Command = "Get-WmiObject -Class Win32_OperatingSystem | Select-Object Caption, Version, BuildNumber, InstallDate, LastBootUpTime, TotalVisibleMemorySize, FreePhysicalMemory, SerialNumber"
            Description = "Operating System Details"
            OutputFile = "$LogPath\02_OSDetails.txt"
        }
    )
    
    foreach ($cmd in $commands) {
        Invoke-SafeCommand -Command $cmd.Command -Description $cmd.Description -OutputFile $cmd.OutputFile
    }
}

function Get-HardwareInformation {
    param([string]$LogPath)
    
    Write-Header "HARDWARE INFORMATION"
    
    $commands = @(
        @{
            Command = "Get-WmiObject -Class Win32_Processor | Select-Object Name, Manufacturer, MaxClockSpeed, NumberOfCores, NumberOfLogicalProcessors, ProcessorId"
            Description = "Processor Information"
            OutputFile = "$LogPath\03_Processor.txt"
        },
        @{
            Command = "Get-WmiObject -Class Win32_PhysicalMemory | Select-Object Capacity, Speed, Manufacturer, PartNumber, SerialNumber"
            Description = "Memory Information"
            OutputFile = "$LogPath\04_Memory.txt"
        },
        @{
            Command = "Get-WmiObject -Class Win32_DiskDrive | Select-Object Model, Size, InterfaceType, MediaType, SerialNumber"
            Description = "Storage Information"
            OutputFile = "$LogPath\05_Storage.txt"
        },
        @{
            Command = "Get-WmiObject -Class Win32_VideoController | Select-Object Name, AdapterRAM, DriverVersion, DriverDate"
            Description = "Graphics Information"
            OutputFile = "$LogPath\06_Graphics.txt"
        }
    )
    
    foreach ($cmd in $commands) {
        Invoke-SafeCommand -Command $cmd.Command -Description $cmd.Description -OutputFile $cmd.OutputFile
    }
}

function Get-NetworkInformation {
    param([string]$LogPath)
    
    Write-Header "NETWORK INFORMATION"
    
    $commands = @(
        @{
            Command = "Get-WmiObject -Class Win32_NetworkAdapter | Where-Object {`$_.NetConnectionStatus -eq 2} | Select-Object Name, AdapterType, Speed, MACAddress, NetConnectionID"
            Description = "Network Adapters"
            OutputFile = "$LogPath\07_NetworkAdapters.txt"
        },
        @{
            Command = "ipconfig /all"
            Description = "IP Configuration"
            OutputFile = "$LogPath\08_IPConfig.txt"
        },
        @{
            Command = "Get-NetRoute | Select-Object DestinationPrefix, NextHop, RouteMetric, InterfaceAlias"
            Description = "Network Routes"
            OutputFile = "$LogPath\09_NetworkRoutes.txt"
        }
    )
    
    foreach ($cmd in $commands) {
        Invoke-SafeCommand -Command $cmd.Command -Description $cmd.Description -OutputFile $cmd.OutputFile
    }
}

function Get-ProcessInformation {
    param([string]$LogPath)
    
    Write-Header "PROCESS INFORMATION"
    
    $commands = @(
        @{
            Command = "Get-Process | Select-Object ProcessName, Id, CPU, WorkingSet, StartTime, Path | Sort-Object CPU -Descending | Select-Object -First 50"
            Description = "Top 50 Running Processes"
            OutputFile = "$LogPath\10_RunningProcesses.txt"
        },
        @{
            Command = "Get-Service | Where-Object {`$_.Status -eq 'Running'} | Select-Object Name, DisplayName, Status, StartType | Sort-Object Name"
            Description = "Running Services"
            OutputFile = "$LogPath\11_RunningServices.txt"
        }
    )
    
    foreach ($cmd in $commands) {
        Invoke-SafeCommand -Command $cmd.Command -Description $cmd.Description -OutputFile $cmd.OutputFile
    }
}

function Get-SoftwareInformation {
    param([string]$LogPath)
    
    Write-Header "SOFTWARE INFORMATION"
    
    $commands = @(
        @{
            Command = "Get-WmiObject -Class Win32_Product | Select-Object Name, Version, Vendor, InstallDate | Sort-Object Name"
            Description = "Installed Software"
            OutputFile = "$LogPath\12_InstalledSoftware.txt"
        },
        @{
            Command = "Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | Select-Object DisplayName, DisplayVersion, Publisher, InstallDate | Sort-Object DisplayName"
            Description = "Registry Installed Programs"
            OutputFile = "$LogPath\13_RegistryPrograms.txt"
        }
    )
    
    foreach ($cmd in $commands) {
        Invoke-SafeCommand -Command $cmd.Command -Description $cmd.Description -OutputFile $cmd.OutputFile
    }
}

function Get-EnvironmentInformation {
    param([string]$LogPath)
    
    Write-Header "ENVIRONMENT INFORMATION"
    
    $commands = @(
        @{
            Command = "Get-ChildItem Env: | Sort-Object Name"
            Description = "Environment Variables"
            OutputFile = "$LogPath\14_Environment.txt"
        },
        @{
            Command = "Get-ChildItem Env:PATH"
            Description = "System PATH"
            OutputFile = "$LogPath\15_SystemPath.txt"
        }
    )
    
    foreach ($cmd in $commands) {
        Invoke-SafeCommand -Command $cmd.Command -Description $cmd.Description -OutputFile $cmd.OutputFile
    }
}

function Get-EventLogs {
    param([string]$LogPath)
    
    Write-Header "EVENT LOGS"
    
    try {
        $yesterday = (Get-Date).AddDays(-1)
        $events = Get-WinEvent -FilterHashtable @{LogName='System','Application'; Level=1,2,3; StartTime=$yesterday} -MaxEvents 100 -ErrorAction SilentlyContinue
        
        if ($events) {
            $events | Select-Object TimeCreated, Id, LevelDisplayName, LogName, ProviderName, Message | 
            Sort-Object TimeCreated -Descending |
            ForEach-Object {
                $sanitized = Remove-PrivacyData -Content ($_ | Out-String)
                $sanitized
            } |
            Out-File -FilePath "$LogPath\16_RecentEvents.txt" -Encoding UTF8
            Write-LogEntry "✓ Recent Event Logs - Saved to 16_RecentEvents.txt" "SUCCESS"
        } else {
            "No recent events found" | Out-File -FilePath "$LogPath\16_RecentEvents.txt" -Encoding UTF8
            Write-LogEntry "⚠ Recent Event Logs - No events found" "WARN"
        }
    }
    catch {
        "Error collecting event logs: $($_.Exception.Message)" | Out-File -FilePath "$LogPath\16_RecentEvents.txt" -Encoding UTF8
        Write-LogEntry "✗ Recent Event Logs - $($_.Exception.Message)" "ERROR"
    }
}

function Get-DiskInformation {
    param([string]$LogPath)
    
    Write-Header "DISK INFORMATION"
    
    $commands = @(
        @{
            Command = "Get-WmiObject -Class Win32_LogicalDisk | Select-Object DeviceID, Size, FreeSpace, FileSystem, VolumeName"
            Description = "Disk Usage"
            OutputFile = "$LogPath\17_DiskUsage.txt"
        }
    )
    
    foreach ($cmd in $commands) {
        Invoke-SafeCommand -Command $cmd.Command -Description $cmd.Description -OutputFile $cmd.OutputFile
    }
}
#endregion

#region Main Functions
function Show-Help {
    Write-Host @"
CnestKwikLog v$SCRIPT_VERSION - Production-Ready System Information Collector

USAGE:
    .\CnestKwikLog.ps1 [OPTIONS]

OPTIONS:
    -LogPath <path>        Output directory (default: .\Logs\LogYYYYMMDD_HHMMSS)
    -PrivacyMode           Enable privacy mode (redacts sensitive data)
    -Verbose               Enable verbose logging
    -ConfigFile <path>     Configuration file path (default: .\config.json)
    -Help                  Show this help message

EXAMPLES:
    .\CnestKwikLog.ps1
    .\CnestKwikLog.ps1 -PrivacyMode
    .\CnestKwikLog.ps1 -LogPath "C:\IncidentResponse\Logs"
    .\CnestKwikLog.ps1 -PrivacyMode -Verbose

FEATURES:
    - Zero-install (no dependencies)
    - Read-only operations
    - Privacy controls
    - Error handling and recovery
    - Neat, organized artifacts
    - GitHub-ready structure

For more information, visit: https://github.com/auxk0rd/CnestKwikLog
"@
}

function Initialize-Collection {
    param([string]$LogPath)
    
    # Create log directory
    if (!(Test-Path $LogPath)) {
        try {
            New-Item -ItemType Directory -Path $LogPath -Force | Out-Null
            Write-LogEntry "Created log directory: $LogPath" "SUCCESS"
        }
        catch {
            Write-LogEntry "Failed to create log directory: $($_.Exception.Message)" "ERROR"
            exit $ERROR_CODES.FILE_SYSTEM_ERROR
        }
    }
    
    # Initialize log file
    $global:LogFile = "$LogPath\collection.log"
    
    # Write collection header
    $header = @"
CnestKwikLog Collection Report
==============================
Version: $SCRIPT_VERSION
Generated: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
Log Directory: $LogPath
Privacy Mode: $PrivacyMode
Computer: $env:COMPUTERNAME
User: $env:USERNAME
PowerShell Version: $($PSVersionTable.PSVersion)

"@
    $header | Out-File -FilePath "$LogPath\00_CollectionSummary.txt" -Encoding UTF8
    
    Write-LogEntry "Starting CnestKwikLog collection..." "INFO"
    Write-LogEntry "Log directory: $LogPath" "INFO"
    Test-PrivacyMode
}

function Complete-Collection {
    param([string]$LogPath)
    
    Write-Header "COLLECTION SUMMARY"
    
    # Count files and calculate sizes
    $logFiles = Get-ChildItem -Path $LogPath -Filter "*.txt" | Sort-Object Name
    $totalSize = ($logFiles | Measure-Object -Property Length -Sum).Sum
    
    # Update summary
    $summary = @"

Collection completed successfully!
==================================
Total files created: $($logFiles.Count)
Total size: $([math]::Round($totalSize/1KB, 2)) KB
Collection time: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")

Files created:
"@
    
    foreach ($file in $logFiles) {
        $summary += "`n- $($file.Name) ($([math]::Round($file.Length/1KB, 2)) KB)"
    }
    
    $summary += "`n`nCollection completed at: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")"
    
    Add-Content -Path "$LogPath\00_CollectionSummary.txt" -Value $summary -Encoding UTF8
    
    Write-LogEntry "Collection completed successfully!" "SUCCESS"
    Write-LogEntry "Total files created: $($logFiles.Count)" "SUCCESS"
    Write-LogEntry "Total size: $([math]::Round($totalSize/1KB, 2)) KB" "SUCCESS"
    Write-LogEntry "Log directory: $LogPath" "SUCCESS"
}

function Main {
    # Show help if requested
    if ($Help) {
        Show-Help
        exit $ERROR_CODES.SUCCESS
    }
    
    # Initialize collection
    Initialize-Collection -LogPath $LogPath
    
    # Collect system information
    Get-SystemInformation -LogPath $LogPath
    Get-HardwareInformation -LogPath $LogPath
    Get-NetworkInformation -LogPath $LogPath
    Get-ProcessInformation -LogPath $LogPath
    Get-SoftwareInformation -LogPath $LogPath
    Get-EnvironmentInformation -LogPath $LogPath
    Get-EventLogs -LogPath $LogPath
    Get-DiskInformation -LogPath $LogPath
    
    # Complete collection
    Complete-Collection -LogPath $LogPath
    
    Write-LogEntry "CnestKwikLog collection completed successfully!" "SUCCESS"
    exit $ERROR_CODES.SUCCESS
}
#endregion

# Execute main function
Main
