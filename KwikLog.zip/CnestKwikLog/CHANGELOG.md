# Changelog

All notable changes to CnestKwikLog will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## \[2.0.0] - 2025-10-18

### Added

* Production-ready architecture with modular design
* Comprehensive privacy controls with data sanitization
* Advanced error handling and recovery mechanisms
* Timeout protection for long-running commands
* Verbose logging and debugging capabilities
* Configuration file support
* GitHub-ready structure with documentation
* Professional batch launcher with argument parsing
* Comprehensive help system
* MIT license and proper attribution

### Enhanced

* Improved PowerShell script reliability and error handling
* Better organization of collected data
* Enhanced privacy mode with more sensitive data redaction
* More comprehensive system information collection
* Better file naming and organization
* Improved logging and progress indicators

### Security

* Read-only operations to prevent system modification
* Privacy mode to redact sensitive information
* Safe command execution with timeout protection
* Input validation and sanitization

### Documentation

* Comprehensive README with usage examples
* Professional documentation structure
* GitHub-ready with badges and proper formatting
* Changelog and license files
* Proper .gitignore for Windows development

## \[1.0.0] - 2025

### Added

* Initial MVP release
* Basic system information collection
* DOS-style batch launcher
* PowerShell collector script
* Simple log directory management
* Basic error handling

### Features

* System information collection
* Hardware details
* Network configuration
* Process and service information
* Installed software inventory
* Environment variables
* Event logs
* Disk usage information
